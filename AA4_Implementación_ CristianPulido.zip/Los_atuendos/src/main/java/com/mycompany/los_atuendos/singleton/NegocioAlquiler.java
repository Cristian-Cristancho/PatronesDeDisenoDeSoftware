
package com.mycompany.los_atuendos.singleton;

/**
 *
 * @author cpulidoc
 */
import com.mycompany.los_atuendos.model.*;
import java.util.ArrayList;
import java.util.List;

public class NegocioAlquiler {
    private static NegocioAlquiler instanciaUnica;
    
    // Las listas ahora son privadas y finales, accedidas mediante getters (o Facade)
    private final List<Empleado> listaEmpleados; 
    private final List<ServicioAlquiler> serviciosAlquiler; 

    private NegocioAlquiler() {
        listaEmpleados = new ArrayList<>();
        serviciosAlquiler = new ArrayList<>();
        // Inicialización de datos crucial
        listaEmpleados.add(new Empleado("E1", "Juan Perez", "Cra 1", "3001234567", "Administrador"));
    }

    public static NegocioAlquiler getInstance() {
        if (instanciaUnica == null) {
            instanciaUnica = new NegocioAlquiler();
        }
        return instanciaUnica;
    }
    
    // Métodos de negocio accesibles
    public void registrarServicio(ServicioAlquiler servicio) {
        this.serviciosAlquiler.add(servicio);
        System.out.println("SINGLETON: Servicio N°" + servicio.getNumero() + " registrado. (" + serviciosAlquiler.size() + " en total)");
    }
    
    // Getter esencial para que la Fachada pueda buscar empleados
    public Empleado buscarEmpleado(String id) {
        return listaEmpleados.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
}