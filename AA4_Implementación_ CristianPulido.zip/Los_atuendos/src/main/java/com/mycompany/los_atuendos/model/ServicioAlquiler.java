
package com.mycompany.los_atuendos.model;

/**
 *
 * @author cpulidoc
 */
import java.util.Date;
import java.util.List;

public class ServicioAlquiler {
    private int numero;
    private Date fechaSolic;
    private Date fechaAlqui;
    private Empleado empleado;
    private Cliente cliente;
    private List<ComponentePrenda> alquileres;

    public ServicioAlquiler(int numero, Date fechaSolic, Date fechaAlqui, Empleado empleado, Cliente cliente, List<ComponentePrenda> alquileres) {
        this.numero = numero;
        this.fechaSolic = fechaSolic;
        this.fechaAlqui = fechaAlqui;
        this.empleado = empleado;
        this.cliente = cliente;
        this.alquileres = alquileres;
    }

    public double getValorTotal() {
        double total = 0;
        for (ComponentePrenda p : alquileres) {
            total += p.getValorAlquiler();
        }
        return total;
    }
    
    public int getNumero() { return numero; }
    // ... otros getters y setters
}
