/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.los_atuendos.model;

/**
 *
 * @author cpulidoc
 */
public class VestidoDama extends Prenda {
    private boolean pedreria;
    private String altura; 
    private int cantPiezas;

    public VestidoDama(String ref, String color, String marca, String talla, double valorAlquiler, boolean pedreria, String altura, int cantPiezas) {
        super(ref, color, marca, talla, valorAlquiler);
        this.pedreria = pedreria;
        this.altura = altura;
        this.cantPiezas = cantPiezas;
    }

    public boolean isPedreria() {
        return pedreria;
    }

    public void setPedreria(boolean pedreria) {
        this.pedreria = pedreria;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }

    public int getCantPiezas() {
        return cantPiezas;
    }

    public void setCantPiezas(int cantPiezas) {
        this.cantPiezas = cantPiezas;
    }

    @Override
    public String getDetalles() {
        return "Vestido Dama - Ref: " + ref + ", Talla: " + talla + ", Pedrería: " + pedreria + ", Piezas: " + cantPiezas;
    }
}

