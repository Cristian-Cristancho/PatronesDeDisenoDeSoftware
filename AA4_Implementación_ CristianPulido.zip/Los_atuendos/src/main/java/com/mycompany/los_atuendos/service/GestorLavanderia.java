
package com.mycompany.los_atuendos.service;

/**
 *
 * @author cpulidoc
 */
import com.mycompany.los_atuendos.model.ComponentePrenda;
import com.mycompany.los_atuendos.model.VestidoDama;
import com.mycompany.los_atuendos.model.PrendaCompuesta;

public class GestorLavanderia {
    public void registrarParaLavado(ComponentePrenda prenda, boolean esPrioritaria) {
        String prioridad = esPrioritaria ? "PRIORITARIA (Delicada)" : "NORMAL";
        // Muestra el detalle de la primera línea (para no imprimir todo el Composite)
        String detalle = prenda.getDetalles().split("\n")[0]; 
        System.out.println("-> LAVANDERÍA: Prenda (" + detalle + ") registrada. Cola: " + prioridad);
    }

    public void enviarTanda() {
        System.out.println("-> LAVANDERÍA: Tanda de prendas enviada a lavado por restricciones logísticas.");
    }
}
