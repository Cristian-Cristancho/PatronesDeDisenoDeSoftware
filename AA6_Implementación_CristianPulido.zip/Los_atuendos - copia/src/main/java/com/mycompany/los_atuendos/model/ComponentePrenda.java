
package com.mycompany.los_atuendos.model;

/**
 *
 * @author cpulidoc
 */
public interface ComponentePrenda {
    double getValorAlquiler();
    String getDetalles();
}