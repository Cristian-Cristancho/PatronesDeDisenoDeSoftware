
package com.mycompany.los_atuendos;

import com.mycompany.los_atuendos.factory.FabricaPrendas;
import com.mycompany.los_atuendos.model.ComponentePrenda;
import com.mycompany.los_atuendos.model.PrendaCompuesta;
import com.mycompany.los_atuendos.service.FachadaAtuendos;
import java.util.List;
/**
 *
 * @author cpulidoc
 */
public class Los_atuendos {

    public static void main(String[] args) {
        System.out.println("--- INICIANDO PROYECTO LOS ATUENDOS ---");
        
        FachadaAtuendos fachada = new FachadaAtuendos();
        FabricaPrendas fabrica = new FabricaPrendas();
        
        // --- 1. CREACIÓN DE PRENDAS (Factory Method en acción) ---
        // Vestido Dama: ref, color, marca, talla, valor, pedreria(str), altura, piezas(str)
        ComponentePrenda vestidoLargo = fabrica.crearPrenda("VESTIDODAMA", "V001", "Rojo", "Gucci", "S", 150.0, "true", "Largo", "3");
        // Traje Caballero: ref, color, marca, talla, valor, tipo, aderezo
        ComponentePrenda pantalon = fabrica.crearPrenda("TRAJECABALLERO", "P002", "Negro", "Boss", "L", 80.0, "Sacoleva", "Ninguno");
        ComponentePrenda corbatin = fabrica.crearPrenda("TRAJECABALLERO", "C003", "Azul", "Boss", "U", 20.0, "Otro", "Corbatín");
    
        // --- 2. CREACIÓN DE CONJUNTO (Composite en acción) ---
        PrendaCompuesta trajeBoda = new PrendaCompuesta();
        trajeBoda.agregar(vestidoLargo); // El vestido forma parte del conjunto
        trajeBoda.agregar(pantalon);
        trajeBoda.agregar(corbatin);
        
        System.out.println("\n--- PRUEBA COMPOSITE: Traje de Boda ---");
        System.out.println(trajeBoda.getDetalles());
        System.out.println("El valor total del alquiler es: $" + trajeBoda.getValorAlquiler());

        // --- 3. SOLICITAR ALQUILER (Facade y Singleton en acción) ---
        List<ComponentePrenda> alquilerSolicitado = List.of(trajeBoda); // Alquila el Composite
        fachada.solicitarAlquiler("C001", "Carlos Cliente", "E1", alquilerSolicitado);
        
        // --- 4. DEVOLVER PRENDAS (Facade y Subsistemas en acción) ---
        fachada.devolverPrendas(alquilerSolicitado); // Se envía el Composite a lavar
    }
}
