
package com.mycompany.los_atuendos.model;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author cpulidoc
 */
public class PrendaCompuesta implements ComponentePrenda {
    private List<ComponentePrenda> componentes = new ArrayList<>();

    public void agregar(ComponentePrenda componente) {
        componentes.add(componente);
    }
    // otros métodos de Composite como eliminar, etc.)

    @Override
    public double getValorAlquiler() {
        double valorTotal = 0;
        for (ComponentePrenda c : componentes) {
            valorTotal += c.getValorAlquiler();
        }
        return valorTotal;
    }

    @Override
    public String getDetalles() {
        StringBuilder sb = new StringBuilder("Conjunto compuesto (Total: " + componentes.size() + " piezas):\n");
        for (ComponentePrenda c : componentes) {
            sb.append("  -> ").append(c.getDetalles()).append("\n");
        }
        return sb.toString();
    }
}
