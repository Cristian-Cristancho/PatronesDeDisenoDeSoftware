
package com.mycompany.los_atuendos.factory;

/**
 *
 * @author cpulidoc
 */
import com.mycompany.los_atuendos.model.ComponentePrenda;
import com.mycompany.los_atuendos.model.VestidoDama;
import com.mycompany.los_atuendos.model.TrajeCaballero;

public class FabricaPrendas {
    // Método para crear instancias específicas sin acoplar el código llamador
    public ComponentePrenda crearPrenda(String tipo, String ref, String color, String marca, String talla, double valor, String... extras) {
        switch (tipo.toUpperCase()) {
            case "VESTIDODAMA":
                // extras: [0]pedreria(str), [1]altura, [2]cantPiezas(str)
                boolean pedreria = Boolean.parseBoolean(extras[0]);
                int cantPiezas = Integer.parseInt(extras[2]);
                return new VestidoDama(ref, color, marca, talla, valor, pedreria, extras[1], cantPiezas);
            case "TRAJECABALLERO":
                // extras: [0]tipo, [1]aderezo
                return new TrajeCaballero(ref, color, marca, talla, valor, extras[0], extras[1]);
            case "DISFRAZ":
                // Implementación para Disfraz (usando extras[0] para el nombre)
                // return new Disfraz(ref, color, marca, talla, valor, extras[0]);
            default:
                throw new IllegalArgumentException("Tipo de prenda desconocido: " + tipo);
        }
    }
}