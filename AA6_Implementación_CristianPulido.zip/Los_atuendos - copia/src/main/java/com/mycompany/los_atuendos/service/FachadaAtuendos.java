/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.los_atuendos.service;

/**
 *
 * @author cpulidoc
 */
import com.mycompany.los_atuendos.singleton.NegocioAlquiler;
import com.mycompany.los_atuendos.model.*;
import java.util.Date;
import java.util.List;

public class FachadaAtuendos {
    private final NegocioAlquiler negocio; // Subsistema 1 (Singleton)
    private final GestorLavanderia lavanderia; // Subsistema 2

    public FachadaAtuendos() {
        this.negocio = NegocioAlquiler.getInstance(); 
        this.lavanderia = new GestorLavanderia();
    }

    // OPERACIÓN FACHADA: Solicitar un nuevo alquiler
    public void solicitarAlquiler(String idCliente, String nombreCliente, String idEmpleado, List<ComponentePrenda> prendas) {
        Cliente cliente = new Cliente(idCliente, nombreCliente, "Dir", "Tel", "mail"); 
        Empleado empleado = negocio.buscarEmpleado(idEmpleado);
        
        if (empleado == null) {
             System.out.println("FACHADA ERROR: Empleado con ID " + idEmpleado + " no encontrado."); return;
        }

        ServicioAlquiler nuevoServicio = new ServicioAlquiler(1001 + (int)(Math.random() * 100), new Date(), new Date(), empleado, cliente, prendas);
        
        negocio.registrarServicio(nuevoServicio);
        System.out.println("FACHADA: Alquiler solicitado por " + cliente.getNombre() + ". Total: $" + nuevoServicio.getValorTotal());
    }

    // OPERACIÓN FACHADA: Devolución de prendas
    public void devolverPrendas(List<ComponentePrenda> prendasDevueltas) {
        System.out.println("\nFACHADA: Iniciando proceso de Devolución y Lavandería...");
        
        for (ComponentePrenda prenda : prendasDevueltas) {
            // Lógica de prioridad: Vestidos o conjuntos (Composite) son delicados/manchados
            boolean esPrioritaria = (prenda instanceof VestidoDama) || (prenda instanceof PrendaCompuesta);
            lavanderia.registrarParaLavado(prenda, esPrioritaria); 
        }
        
        lavanderia.enviarTanda();
    }
}
