/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.los_atuendos.model;

/**
 *
 * @author cpulidoc
 */
public class TrajeCaballero extends Prenda {
    private String tipo; 
    private String aderezo; 

    public TrajeCaballero(String ref, String color, String marca, String talla, double valorAlquiler, String tipo, String aderezo) {
        super(ref, color, marca, talla, valorAlquiler);
        this.tipo = tipo;
        this.aderezo = aderezo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getAderezo() {
        return aderezo;
    }

    public void setAderezo(String aderezo) {
        this.aderezo = aderezo;
    }
    
    @Override
    public String getDetalles() {
        return "Traje Caballero - Ref: " + ref + ", Tipo: " + tipo + ", Aderezo: " + aderezo;
    }
}